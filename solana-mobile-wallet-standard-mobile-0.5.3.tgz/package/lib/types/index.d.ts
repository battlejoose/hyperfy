import { SolanaSignAndSendTransactionFeature, SolanaSignInFeature, SolanaSignMessageFeature, SolanaSignTransactionFeature } from "@solana/wallet-standard-features";
import { AppIdentity, AuthorizationResult, GetCapabilitiesAPI } from "@solana-mobile/mobile-wallet-adapter-protocol";
import { IdentifierArray, IdentifierString, Wallet, WalletAccount } from "@wallet-standard/base";
import { StandardConnectFeature, StandardDisconnectFeature, StandardEventsFeature } from "@wallet-standard/features";

//#region src/wallet.d.ts
type WalletCapabilities = Awaited<ReturnType<GetCapabilitiesAPI['getCapabilities']>>;
type Authorization = AuthorizationResult & Readonly<{
  chain: IdentifierString;
  capabilities: WalletCapabilities;
}>;
interface AuthorizationCache {
  clear(): Promise<void>;
  get(): Promise<Authorization | undefined>;
  set(authorization: Authorization): Promise<void>;
}
interface ChainSelector {
  select(chains: IdentifierArray): Promise<IdentifierString>;
}
declare const SolanaMobileWalletAdapterWalletName = "Mobile Wallet Adapter";
declare const SolanaMobileWalletAdapterRemoteWalletName = "Remote Mobile Wallet Adapter";
interface SolanaMobileWalletAdapterWallet extends Wallet {
  url: string;
}
interface SolanaMobileWalletAdapterAuthorization {
  get isAuthorized(): boolean;
  get currentAuthorization(): Authorization | undefined;
  get cachedAuthorizationResult(): Promise<Authorization | undefined>;
}
declare class LocalSolanaMobileWalletAdapterWallet implements SolanaMobileWalletAdapterWallet, SolanaMobileWalletAdapterAuthorization {
  #private;
  get version(): "1.0.0";
  get name(): string;
  get url(): string;
  get icon(): `data:image/svg+xml;base64,${string}` | `data:image/webp;base64,${string}` | `data:image/png;base64,${string}` | `data:image/gif;base64,${string}`;
  get chains(): IdentifierArray;
  get features(): StandardConnectFeature & StandardDisconnectFeature & StandardEventsFeature & SolanaSignMessageFeature & SolanaSignInFeature & (SolanaSignAndSendTransactionFeature | SolanaSignTransactionFeature);
  get accounts(): WalletAccount[];
  constructor(config: {
    appIdentity: AppIdentity;
    authorizationCache: AuthorizationCache;
    chains: IdentifierArray;
    chainSelector: ChainSelector;
    onWalletNotFound: (mobileWalletAdapter: SolanaMobileWalletAdapterWallet) => Promise<void>;
  });
  get connected(): boolean;
  get isAuthorized(): boolean;
  get currentAuthorization(): Authorization | undefined;
  get cachedAuthorizationResult(): Promise<Authorization | undefined>;
}
declare class RemoteSolanaMobileWalletAdapterWallet implements SolanaMobileWalletAdapterWallet, SolanaMobileWalletAdapterAuthorization {
  #private;
  get version(): "1.0.0";
  get name(): string;
  get url(): string;
  get icon(): `data:image/svg+xml;base64,${string}` | `data:image/webp;base64,${string}` | `data:image/png;base64,${string}` | `data:image/gif;base64,${string}`;
  get chains(): IdentifierArray;
  get features(): StandardConnectFeature & StandardDisconnectFeature & StandardEventsFeature & SolanaSignMessageFeature & SolanaSignInFeature & (SolanaSignAndSendTransactionFeature | SolanaSignTransactionFeature);
  get accounts(): WalletAccount[];
  constructor(config: {
    appIdentity: AppIdentity;
    authorizationCache: AuthorizationCache;
    chains: IdentifierArray;
    chainSelector: ChainSelector;
    remoteHostAuthority: string;
    onWalletNotFound: (mobileWalletAdapter: SolanaMobileWalletAdapterWallet) => Promise<void>;
  });
  get connected(): boolean;
  get isAuthorized(): boolean;
  get currentAuthorization(): Authorization | undefined;
  get cachedAuthorizationResult(): Promise<Authorization | undefined>;
}
//#endregion
//#region src/createDefaultAuthorizationCache.d.ts
declare function createDefaultAuthorizationCache(): AuthorizationCache;
//#endregion
//#region src/createDefaultChainSelector.d.ts
declare function createDefaultChainSelector(): ChainSelector;
//#endregion
//#region src/createDefaultWalletNotFoundHandler.d.ts
declare function defaultErrorModalWalletNotFoundHandler(): Promise<void>;
declare function createDefaultWalletNotFoundHandler(): (mobileWalletAdapter: SolanaMobileWalletAdapterWallet) => Promise<void>;
//#endregion
//#region src/initialize.d.ts
declare function registerMwa(config: {
  appIdentity: AppIdentity;
  authorizationCache: AuthorizationCache;
  chains: IdentifierArray;
  chainSelector: ChainSelector;
  remoteHostAuthority?: string;
  onWalletNotFound: (mobileWalletAdapter: SolanaMobileWalletAdapterWallet) => Promise<void>;
}): void;
//#endregion
export { Authorization, AuthorizationCache, ChainSelector, LocalSolanaMobileWalletAdapterWallet, RemoteSolanaMobileWalletAdapterWallet, SolanaMobileWalletAdapterRemoteWalletName, SolanaMobileWalletAdapterWallet, SolanaMobileWalletAdapterWalletName, createDefaultAuthorizationCache, createDefaultChainSelector, createDefaultWalletNotFoundHandler, defaultErrorModalWalletNotFoundHandler, registerMwa };
//# sourceMappingURL=index.d.ts.map